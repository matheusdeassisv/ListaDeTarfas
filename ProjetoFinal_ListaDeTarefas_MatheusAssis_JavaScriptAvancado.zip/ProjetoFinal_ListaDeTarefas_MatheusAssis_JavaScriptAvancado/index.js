const express = require('express');
const path = require("path");
const routes = require('./routes/routes');
const conectToDb = require('./database/db');
const doteenv = require('dotenv');
doteenv.config();
const app = express();
const port = 5005;

conectToDb();

app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded());
app.use(routes); //funcao que gera as rotas do prj

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}/`)
})