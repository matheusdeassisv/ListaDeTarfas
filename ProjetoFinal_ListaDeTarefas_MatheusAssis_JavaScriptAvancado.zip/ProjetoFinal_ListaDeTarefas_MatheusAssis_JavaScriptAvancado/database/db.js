const mongoose = require('mongoose');
mongoose.set("strictQuery",true);
const conectToDb = async () => {
    await  mongoose.connect(process.env.DB_URI,
    
        (err) => {
            if (err){
                return console.log('erro ao conectar com o banco: ' , err);
            }
            return console.log('Conexão realizada com sucesso');
        }
)}


module.exports = conectToDb;